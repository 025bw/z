/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Cert;
import model.Stu;
import model.StuCert;

/**
 *
 * @author z
 */
public class StuDAO extends DBContext {

    public ArrayList liststu() {
        ArrayList<Stu> stus = new ArrayList<>();
        String sql = "SELECT * from Student";
        PreparedStatement stm;
        try {
            stm = connection.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Stu stu = new Stu();
                stu.setId(rs.getInt("id"));

                stu.setName(rs.getString("name"));
                stus.add(stu);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return stus;
    }

    public ArrayList listcert() {
        ArrayList<Cert> stus = new ArrayList<>();
        String sql = "SELECT id,name from Certificate";
        PreparedStatement stm;
        try {
            stm = connection.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Cert stu = new Cert();
                stu.setId(rs.getInt("id"));

                stu.setName(rs.getString("name"));
                stus.add(stu);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return stus;
    }

    public ArrayList liststucert() {
        ArrayList<StuCert> stus = new ArrayList<>();
        String sql = "SELECT * from Student_Certificate";
        PreparedStatement stm;
        try {
            stm = connection.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                StuCert stu = new StuCert();
                stu.setSid(rs.getInt("sid"));
                stu.setCid(rs.getInt("cid"));
                stus.add(stu);
            }
        } catch (SQLException ex) {
            Logger.getLogger(StuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return stus;
    }

    public void delete() {
        try {
            String sql = "DELETE FROM [dbo].[Student_Certificate]";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(StuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void insert(StuCert model) {
        try {
            String sql = "INSERT INTO [dbo].[Student_Certificate]\n"
                    + "           ([sid]\n"
                    + "           ,[cid])\n"
                    + "     VALUES\n"
                    + "           (?\n"
                    + "           ,?)";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setInt(1, model.getSid());
            stm.setInt(2, model.getCid());
            stm.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(StuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
